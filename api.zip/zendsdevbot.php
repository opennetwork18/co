<?php
$idtele = "7729293498";//id tele
$token = "7699362623:AAFK6IVMs23WYiy77hUM3b5eEYfLnGc2084";//token bot
?>
